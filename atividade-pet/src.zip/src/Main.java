public class Main {
    public static void main(String[] args) {
        Pet pet1 = new Pet();
        Pet pet2 = new Pet("myuki");
        Pet pet3 = new Pet("niko", "alysson", 2020,
                            "felino", "sem raca");

    }
}